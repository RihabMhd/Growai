<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('teams', function (Blueprint $table) {
            $table->unsignedBigInteger('dispatch_cursor')
                ->default(0)
                ->after('whatsapp_language');

            $table->string('dispatch_hash')
                ->nullable()
                ->after('dispatch_cursor');
        });
    }

    public function down(): void
    {
        Schema::table('teams', function (Blueprint $table) {
            $table->dropColumn([
                'dispatch_cursor',
                'dispatch_hash',
            ]);
        });
    }
};