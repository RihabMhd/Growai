<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('order_histories', function (Blueprint $table) {
            $table->id();

            $table->foreignId('order_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->foreignId('user_id')
                ->nullable()
                ->constrained()
                ->nullOnDelete();

            $table->string('action_type', 50);
            // status_changed | assigned | note_added | payment_updated | ...

            $table->text('old_value')->nullable();
            $table->string('new_value', 100)->nullable();
            $table->text('description')->nullable();

            $table->timestamps();

            $table->index(['order_id', 'new_value'], 'idx_order_histories_order_status');

            $table->index('action_type');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('order_histories');
    }
};
